<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="error">
    <p>
        <strong><?php _e('WooCommerce maxiPago', 'woocommerce-maxipago'); ?></strong> <?php _e('needs to have installed on your server the CURL lib to works!', 'woocommerce-maxipago'); ?>
    </p>
</div>